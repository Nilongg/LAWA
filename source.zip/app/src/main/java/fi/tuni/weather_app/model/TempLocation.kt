package fi.tuni.weather_app.model

data class TempLocation(
    val latitude: Double,
    val longitude: Double
)